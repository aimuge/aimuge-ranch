@echo off
chcp 65001 >nul
start "" "%~dp0伊拉特智慧牧场_手机单文件版.html"
