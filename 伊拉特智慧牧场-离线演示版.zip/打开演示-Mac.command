#!/bin/zsh
cd "$(dirname "$0")"
open "伊拉特智慧牧场_手机单文件版.html"
